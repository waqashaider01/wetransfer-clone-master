import React from "react";
import { Transfer } from "./components/Features/transfer/transfer";

import "./App.scss";

export default () => (
  <div className="App">
    <Transfer />
  </div>
);
